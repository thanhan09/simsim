﻿var login = require("facebook-chat-api");
 const axios = require("axios"); 
var answeredThreads = {};
 
// Create simple echo bot
login({email: "0961649004", password: "16190201"}, function callback (err, api) {
    if(err) return console.error(err);
 
    api.listen(function callback(err, message) {
    	var d = new Date();
        var h = d.getHours();
        var m = d.getMinutes();
        var s = d.getSeconds();
        var tin=message.body;
        var id = message.threadID;
        axios.get('http://api.minhhieu.asia/vi.php',{params:{text:message.body}})
        .then( response =>{
            api.sendMessage(response.data+"  --[simsim]", message.threadID);

        })
       
       
        });
    });
